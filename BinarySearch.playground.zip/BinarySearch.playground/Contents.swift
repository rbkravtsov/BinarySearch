import UIKit



func binarySearch(array sortedArray: Array<Int>, number valueToFound: Int) -> Int? {
    var index: Int?
    var isFounded = false
    var start = 0
    var finish = sortedArray.endIndex
    var middle: Int
    while (start <= finish) && !isFounded {
        middle = start + (finish-start)/2
        if sortedArray[middle] == valueToFound {
            isFounded = true
            index = middle
        } else if sortedArray[middle] < valueToFound {
            start = middle + 1
        } else {
            finish = middle - 1
        }
    }
    return index
}
let arrayOfInt = [1,10]
let indexIs = binarySearch(array: arrayOfInt, number: 10)
print(indexIs ?? "none")
